import json
import requests
import os

url_disc = os.getenv('URL_DISC')
token = os.getenv('TOKEN')


def lambda_handler(event, context):
    response = event
    sns = json.loads(response['Records'][0]['Sns']['Message'])
    message = sns.get('detail')
    detailtype = sns.get('detailType')
    state = message.get('state')
    if state == 'STARTED':
        statemsg = 'STARTED! :arrow_forward:'
    elif state == 'SUCCEEDED':
        statemsg = 'SUCCEEDED! :white_check_mark:'
    elif state == 'FAILED':
        statemsg = 'FAILED! :x:'


    if detailtype == 'CodePipeline Pipeline Execution State Change':
        pipeline = message.get('pipeline')
        body = f'{detailtype}\n{pipeline}\nState: {statemsg}'
    elif detailtype == 'CodePipeline Stage Execution State Change':
        pipeline = message.get('pipeline')
        stage = message.get('stage')
        body = f'{detailtype}\n{pipeline}\nStage: {stage}\nState: {statemsg}'
    url = url_disc
    auth = {
        'authorization': token
    }
    msg = {
        'content': body
    }
    requests.post(url, headers=auth, data=msg)